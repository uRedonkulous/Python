README for Updated Values in Dictionaries Assign
