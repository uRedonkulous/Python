REAMDME for for loops basic assign
